create definer = root@localhost trigger GetTime_BEFORE_INSERT_ORDER
    before insert
    on orders
    for each row
    SET NEW.order_time = NOW();


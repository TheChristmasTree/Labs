create definer = root@localhost trigger GetTime_BEFORE_INSERT_COMMENT
    before insert
    on comments
    for each row
    SET NEW.comment_time = NOW();

